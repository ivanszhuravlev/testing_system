var values = {
    reg_user : {
        nick       : 1,
        email      : 1,
        pass_equal : 1
    }
};

angular.module('testApp')
    .value('RegValues', values);